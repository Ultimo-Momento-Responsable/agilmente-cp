(self["webpackChunkagilmente_cp"] = self["webpackChunkagilmente_cp"] || []).push([["src_app_results_results_module_ts"],{

/***/ 4327:
/*!***************************************************!*\
  !*** ./src/app/results/results-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResultsPageRoutingModule": () => (/* binding */ ResultsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _results_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./results.page */ 7307);




const routes = [
    {
        path: '',
        component: _results_page__WEBPACK_IMPORTED_MODULE_0__.ResultsPage
    }
];
let ResultsPageRoutingModule = class ResultsPageRoutingModule {
};
ResultsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ResultsPageRoutingModule);



/***/ }),

/***/ 2325:
/*!*******************************************!*\
  !*** ./src/app/results/results.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResultsPageModule": () => (/* binding */ ResultsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _results_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./results-routing.module */ 4327);
/* harmony import */ var _results_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./results.page */ 7307);







let ResultsPageModule = class ResultsPageModule {
};
ResultsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _results_routing_module__WEBPACK_IMPORTED_MODULE_0__.ResultsPageRoutingModule
        ],
        declarations: [_results_page__WEBPACK_IMPORTED_MODULE_1__.ResultsPage]
    })
], ResultsPageModule);



/***/ }),

/***/ 7307:
/*!*****************************************!*\
  !*** ./src/app/results/results.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResultsPage": () => (/* binding */ ResultsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_results_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./results.page.html */ 4911);
/* harmony import */ var _results_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./results.page.scss */ 552);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 8002);






let ResultsPage = class ResultsPage {
    constructor(http) {
        this.http = http;
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.getResults().subscribe(res => {
            this.results = res;
        });
    }
    /**
    * getResults()
    * @returns {Observable} - Lee los datos del JSON y devuelve los objetos bajo 'results'
    */
    getResults() {
        return this.http
            .get("assets/results.json")
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)((res) => {
            return res.results;
        }));
    }
};
ResultsPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient }
];
ResultsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-results',
        template: _raw_loader_results_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_results_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ResultsPage);



/***/ }),

/***/ 552:
/*!*******************************************!*\
  !*** ./src/app/results/results.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-toolbar.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlc3VsdHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7QUFDSiIsImZpbGUiOiJyZXN1bHRzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyLm1kIGlvbi1jb250ZW50IHtcclxuICAgIC0tcGFkZGluZy1zdGFydDogOHB4O1xyXG4gICAgLS1wYWRkaW5nLWVuZDogOHB4O1xyXG4gICAgLS1wYWRkaW5nLXRvcDogMjBweDtcclxuICAgIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XHJcbn0iXX0= */");

/***/ }),

/***/ 4911:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/results/results.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar color=primary>\r\n    <ion-title>Resultados</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-card *ngFor=\"let result of results\">\r\n    <ion-card-header>\r\n      <ion-card-subtitle>{{result.date}}</ion-card-subtitle>\r\n      <ion-card-title>{{result.patient}}</ion-card-title>\r\n    </ion-card-header>\r\n    <ion-card-content>\r\n      <ion-chip *ngIf=\"result.canceled==false\" color=\"success\">\r\n        <ion-icon name=\"checkmark-circle\"></ion-icon>\r\n        <ion-label>Completo</ion-label>\r\n      </ion-chip>\r\n      <ion-chip *ngIf=\"result.canceled==true\" color=\"danger\">\r\n        <ion-icon name=\"close-circle\"></ion-icon>\r\n        <ion-label>Abandonado</ion-label>\r\n      </ion-chip>\r\n      <ion-label><p>Juego: {{result.name}}</p></ion-label>\r\n      <ion-label><p>Tiempo de juego: {{result.totalTime}}</p></ion-label>\r\n      <ion-chip color=\"success\">\r\n        <ion-icon name=\"checkmark-circle\"></ion-icon>\r\n        <ion-label>Aciertos: {{result.successes}}</ion-label>\r\n      </ion-chip>\r\n      <ion-chip color=\"danger\">\r\n        <ion-icon name=\"close-circle\"></ion-icon>\r\n        <ion-label>Errores: {{result.mistakes}}</ion-label>\r\n      </ion-chip>\r\n    </ion-card-content>\r\n  </ion-card>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_results_results_module_ts.js.map