(self["webpackChunkagilmente_cp"] = self["webpackChunkagilmente_cp"] || []).push([["src_app_patients_patients_module_ts"],{

/***/ 4209:
/*!*****************************************************!*\
  !*** ./src/app/patients/patients-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PatientsPageRoutingModule": () => (/* binding */ PatientsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _patients_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./patients.page */ 5026);




const routes = [
    {
        path: '',
        component: _patients_page__WEBPACK_IMPORTED_MODULE_0__.PatientsPage
    }
];
let PatientsPageRoutingModule = class PatientsPageRoutingModule {
};
PatientsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PatientsPageRoutingModule);



/***/ }),

/***/ 1910:
/*!*********************************************!*\
  !*** ./src/app/patients/patients.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PatientsPageModule": () => (/* binding */ PatientsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _patients_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./patients-routing.module */ 4209);
/* harmony import */ var _patients_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./patients.page */ 5026);







let PatientsPageModule = class PatientsPageModule {
};
PatientsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _patients_routing_module__WEBPACK_IMPORTED_MODULE_0__.PatientsPageRoutingModule
        ],
        declarations: [_patients_page__WEBPACK_IMPORTED_MODULE_1__.PatientsPage]
    })
], PatientsPageModule);



/***/ }),

/***/ 5026:
/*!*******************************************!*\
  !*** ./src/app/patients/patients.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PatientsPage": () => (/* binding */ PatientsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_patients_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./patients.page.html */ 5273);
/* harmony import */ var _patients_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./patients.page.scss */ 8258);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 8002);






let PatientsPage = class PatientsPage {
    constructor(http) {
        this.http = http;
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.getPatients().subscribe(res => {
            this.patients = res;
        });
    }
    /**
    * getPatients()
    * @returns {Observable} - Lee los datos del JSON y devuelve los objetos bajo 'patients'
    */
    getPatients() {
        return this.http
            .get("assets/patients.json")
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)((res) => {
            return res.patients;
        }));
    }
};
PatientsPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient }
];
PatientsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-patients',
        template: _raw_loader_patients_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_patients_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PatientsPage);



/***/ }),

/***/ 8258:
/*!*********************************************!*\
  !*** ./src/app/patients/patients.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".horizontal-cards ion-card {\n  display: inline-block;\n  width: 360px;\n  height: 256px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhdGllbnRzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUFBUiIsImZpbGUiOiJwYXRpZW50cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaG9yaXpvbnRhbC1jYXJkcyB7XHJcbiAgICBpb24tY2FyZCB7XHJcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgIHdpZHRoOiAzNjBweDtcclxuICAgICAgICBoZWlnaHQ6IDI1NnB4O1xyXG4gICAgfVxyXG59Il19 */");

/***/ }),

/***/ 5273:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/patients/patients.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar color=primary>\r\n    <ion-title>Mis Pacientes</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"horizontal-cards\">\r\n  <ion-card *ngFor=\"let patient of patients\">\r\n    <ion-card-header>\r\n      <ion-item>\r\n        <ion-avatar slot=\"start\">\r\n          <img src=\"https://gravatar.com/avatar/dba6bae8c566f9d4041fb9cd9ada7741?d=identicon&f=y\">\r\n        </ion-avatar>\r\n        <ion-label>\r\n          <h3>{{patient.name}}</h3>\r\n          <p>Edad: {{patient.age}}</p>\r\n        </ion-label>\r\n      </ion-item>\r\n      \r\n      <ion-chip *ngFor=\"let domain of patient.domains\">\r\n        <ion-label>{{domain}}</ion-label>\r\n      </ion-chip>\r\n    </ion-card-header>\r\n  \r\n    <ion-card-content>\r\n      {{patient.comment}}\r\n    </ion-card-content>\r\n  </ion-card>\r\n</div>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_patients_patients_module_ts.js.map